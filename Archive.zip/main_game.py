# Main_game.py
# Camryn Echevarria
# 10/4/2022

# don't know why the imports working.

import section_1
import section_5

def main():

    print("Hello there!")

    print("Welcome to Sugar World.")
    print("This world of sugar where sonic looks for his rings on his sugar adventure.")

    print("Let's go!")

    # Then call your first section.

    section_1.start()

if __name__ == "__main__":
    main()