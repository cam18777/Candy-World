# main_character
# camryn echevarria
# 11/6/2022


# This is the list of the character that in the game and what it does.

class main_character:
    # def __init__(self,max_speed,name):
    #     self.max_speed = max_speed
    #     self.name = name
    name = "Sonic"
    money = 0
    life = 3
    inventory = ["gold coin", "sour patch kids", "Candy corn trap", "Throw gumballs bombs"]


# the name of the character didn't work.
