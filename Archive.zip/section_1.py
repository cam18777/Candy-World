# Section_1
# camryn Echevarria
# 11/4/2022

import main_character
import section_2

def start():
    # intro to the game
    print("""Infinite path of sour strips on a bright cotton candy day when sonic is unable to pick the path.
To help sonic find all the rings that will help him complete the adventure.""")

    print("""Sonic is seeking the right path to collect as many rings as possible to win the game.
Sonic has full health and does not know what path to take to start his journey.
While sonic on his crazy adventure that sonic encounters a big decision of witch path to take.""")
    # sonic is thinking where to go first


    input("press 'enter' to continue")
    # pick a path to keep the game going

    while True:
        print("""1. Sugar land
2. Bubble gum land'
3. Chocolate land
4. Gummy land""")

        section_1 = int(input("Which path do you like to pick first?:"))

        if section_1 == 1:
            print("lose half live and all the rings while falling in sour juice river.")

        elif section_1 == 2:
            print("complete the level and now you on to the next level to help collect more ring and lives with sonic.")
            section_2.start()

        if section_1 == 3:
            print("lose half live and all the rings while falling in Nesquik sand.")
        # try to get out of the sand to try to complete the game.
        elif section_1 == 4:
            print("lose half live and all the rings while getting tied up by licorice.")
        else:
            print("Incorrect input")
        # if player picks this struggles getting out of the river

# start()